import customtkinter as ctk
import os, subprocess

root_dir = os.path.dirname(__file__)
os.chdir(root_dir)

def fix_usb():
    cmd = 'chkdsk /f {}:'.format(letter.get())
    output = subprocess.run(cmd, shell=True, check=True, cwd=root_dir, capture_output=True)
    print(output)
    

def main_screen():
    global screen, letter

    screen = ctk.CTk()
    theme_config('dark', 'dark-blue')
    screen.title('USB CORRUPT/UNREADABLE FIX')
    screen.iconbitmap('images/cmd.ico')
    screen.geometry('345x400')
    
    opt_menu_label = ctk.CTkLabel(screen, text='USB DRIVE LETTER TO FIX:', text_color=('black','white'))
    opt_menu_label.pack()

    letter = ctk.StringVar(value='E')

    opt_menu = ctk.CTkOptionMenu(screen, values=['D','E','F','G','H'], variable=letter, anchor='center')
    opt_menu.pack(padx=10, pady=(0,80))

    btn = ctk.CTkButton(screen, text='FIX', command=fix_usb)
    btn.pack(padx=10, pady=(50,20), fill='x')

    def switch_event():
        ctk.set_appearance_mode(theme_state.get())

    theme_state = ctk.StringVar(value='dark')
    ctk.CTkSwitch(screen, text='dark/light', variable=theme_state, onvalue='light', offvalue='dark', command=switch_event).pack()

    screen.mainloop()


def theme_config(theme_mode, theme_color):
    ctk.set_appearance_mode(theme_mode)
    ctk.set_default_color_theme(theme_color)


main_screen()