# The File Or Directory Is Corrupted or UnReadable Fix Using CMD/Python
# @dielnov #iCode4Fun
import os, subprocess

root_dir = os.path.dirname(__file__)
os.chdir(root_dir)
letter = input('Input Letter : ')
cmd = 'chkdsk /f {}:'.format(letter)
output = subprocess.run(cmd, shell=True, check=True, cwd=root_dir, capture_output=True)
print(output)