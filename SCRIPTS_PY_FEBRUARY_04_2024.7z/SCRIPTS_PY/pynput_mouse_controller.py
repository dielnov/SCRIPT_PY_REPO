#Pynput Mouse Controller

from pynput.mouse import Button, Controller

mouse = Controller()

# Read Pointer Position
print("The current pointer position is {0}".format(mouse.position))


# Set Pointer Position
mouse.position = (10, 20)
print("Now we moved it to {0}".format(mouse.position))

# Move Pointer Relative To Current Position
mouse.move(6,733)

# Press & Release Mouse Button
mouse.press(Button.right)
mouse.press(Button.right)

# Double Click (Twice On MacOS)
mouse.click(Button.right, 2)

# Scroll Two Steps Down
mouse.scroll(0,2)


