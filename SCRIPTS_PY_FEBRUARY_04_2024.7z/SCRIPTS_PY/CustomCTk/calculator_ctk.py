from customtkinter import CTk, CTkEntry, CTkButton
from tkinter import StringVar

class Calculator:
    def __init__(self, master):
        master.title('Calculator')
        master.geometry('357x420+0+0')
        master.config(bg='gray')
        master.resizable(False, False)

        self.equation = StringVar()
        self.entry_value = ''
        CTkEntry(master,width=357,border_color='gray', border_width=1, corner_radius=2,fg_color='lightblue',font=('Arial Bold',28),textvariable=self.equation).place(x=0,y=0)

        CTkButton(master,width=80, height=70, text='(',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('(')).place(x=90, y=50)
        CTkButton(master,width=80, height=70, text=')',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show(')')).place(x=0, y=50)
        CTkButton(master,width=80, height=70, text='%',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('%')).place(x=180, y=50)
        CTkButton(master,width=80, height=70, text='1',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('1')).place(x=0, y=125)
        CTkButton(master,width=80, height=70, text='2',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('2')).place(x=90, y=125)
        CTkButton(master,width=80, height=70, text='3',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('3')).place(x=180, y=125)
        CTkButton(master,width=80, height=70, text='4',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('4')).place(x=0, y=200)
        CTkButton(master,width=80, height=70, text='5',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('5')).place(x=90, y=200)
        CTkButton(master,width=80, height=70, text='6',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('6')).place(x=180, y=200)
        CTkButton(master,width=80, height=70, text='7',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('7')).place(x=0, y=275)
        CTkButton(master,width=80, height=70, text='8',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('8')).place(x=180, y=275)
        CTkButton(master,width=80, height=70, text='9',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('9')).place(x=90, y=275)
        CTkButton(master,width=80, height=70, text='0',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('0')).place(x=90, y=350)
        CTkButton(master,width=80, height=70, text='.',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('.')).place(x=180, y=350)
        CTkButton(master,width=80, height=70, text='+',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('+')).place(x=270, y=275)
        CTkButton(master,width=80, height=70, text='-',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('-')).place(x=270, y=200)
        CTkButton(master,width=80, height=70, text='/',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('/')).place(x=270, y=50)
        CTkButton(master,width=80, height=70, text='*',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='white',command=lambda:self.show('*')).place(x=270, y=125)
        CTkButton(master,width=80, height=70, text='=',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='lightblue',command=self.solve).place(x=270, y=350)
        CTkButton(master,width=80, height=70, text='C',border_color='gray', border_width=10, corner_radius=2, text_color='black', fg_color='red', command=self.clear).place(x=0, y=350)

    def show(self, value):
        self.entry_value += str(value)
        self.equation.set(self.entry_value)

    def clear(self):
        self.entry_value = ''
        self.equation.set(self.entry_value)

    def solve(self):
        result = eval(self.entry_value)
        self.equation.set(result)

root = CTk()
calculator = Calculator(root)


root.mainloop()

