import customtkinter as ctk
import os, base64

from tkinter import *
from tkinter import messagebox

os.chdir(os.path.dirname(__file__))

#ctk.set_appearance_mode('dark')
ctk.set_appearance_mode('dark')
ctk.set_default_color_theme('dark-blue')

def error_handler(title, password):
    if password == '':
        messagebox.showerror(title,'Input Security Key!!!')
    elif password != 'asdf0987':
        messagebox.showerror(title,'InValid Security Key!!!')

def encrypt():
    password = code.get()
    if password == 'asdf0987':
        screen1 = Toplevel(screen)
        screen1.title('EnCryption')
        screen1.geometry('400x200')
        screen1.configure(bg='#ed3833')

        message = text1.get(1.0,END)
        encode_message = message.encode('ascii')
        base64_bytes = base64.b64encode(encode_message)
        encrypt = base64_bytes.decode('ascii')

        ctk.CTkLabel(screen1, text='ENCRYPTED TEXT', font=('calbri',13), text_color=('white','white'), fg_color='#ed3833').place(x=10,y=0)
        text2 = ctk.CTkTextbox(screen1, width=340, height=100, font=('Robote', 20), text_color='black', fg_color='white', wrap='word')
        text2.place(x=10,y=40)
        text2.insert(ctk.END,encrypt)
    else:
        error_handler('EnCryption',password)

def decrypt():
    password = code.get()
    if password == 'asdf0987':
        screen1 = Toplevel(screen)
        screen1.title('DeCryption')
        screen1.geometry('400x200')
        screen1.configure(bg='#00bd56')

        message = text1.get(1.0,END)
        decode_message = message.encode('ascii')
        base64_bytes = base64.b64decode(decode_message)
        decrypt = base64_bytes.decode('ascii')

        ctk.CTkLabel(screen1, text='DECRYPTED TEXT', font=('calbri',13), text_color=('white','white'), fg_color='#00bd56').place(x=10,y=0)
        text2 = ctk.CTkTextbox(screen1, width=340, height=100, font=('Robote', 20), text_color='black', fg_color='white', wrap='word')
        text2.place(x=10,y=40)
        text2.insert(ctk.END,decrypt)
    else:
        error_handler('DeCryption',password)


def main_screen():
    global screen, code, text1, theme_state
    screen = ctk.CTk()
    screen.geometry('357x398')
    screen.iconbitmap('images/letter.ico')
    screen.title('EnCryption-DeCryption Tool')

    def switch_event():
        ctk.set_appearance_mode(theme_state.get())


    def reset():
        code.set('')
        text1.delete(1.0,ctk.END)

    ctk.CTkLabel(screen, text='Enter Text To EnCrypt/DeCrypt',text_color=('black','white'), font=('calbri',13)).place(x=10,y=10)
    text1 = ctk.CTkTextbox(screen, width=340, height=100, font=('Robote', 20),text_color='black', fg_color='white', wrap='word')
    text1.place(x=10,y=50)

    ctk.CTkLabel(screen, text='Enter Secret Key For Enc/Dec',text_color=('black','white'), font=('calibri',13)).place(x=10,y=170)
    code = ctk.StringVar()
    ctk.CTkEntry(screen, textvariable=code,width=340, font=('arial',25), show='*').place(x=10,y=200)

    ctk.CTkButton(screen, text='ENCRYPT', width=150, text_color='white', fg_color='#ed3833', command=encrypt).place(x=10, y=250)
    ctk.CTkButton(screen, text='DECRYPT', width=150, text_color='white', fg_color='#00bd56', command=decrypt).place(x=200, y=250)
    ctk.CTkButton(screen, text='RESET', width=336, text_color='white', fg_color='#1089ff', command=reset).place(x=10, y=300)

    theme_state = ctk.StringVar(value='dark')
    ctk.CTkSwitch(screen, text='', variable=theme_state, onvalue='light', offvalue='dark', command=switch_event).place(x=150,y=350)
    screen.mainloop()

main_screen()