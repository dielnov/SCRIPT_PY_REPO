from tkinter import *
import customtkinter
import os

os.chdir(os.path.dirname(__file__))

customtkinter.set_appearance_mode('dark')
customtkinter.set_default_color_theme('dark-blue')

root = customtkinter.CTk()

root.title('CustomTkinter Practical - Scrollable Frames')
root.iconbitmap('images/bomb.ico')
root.geometry('720x480')

scf = customtkinter.CTkScrollableFrame(root,
                                       orientation='vertical',
                                       width=400,
                                       height=300,
                                       label_text='Button List SCF',
                                       label_fg_color='blue',
                                       label_text_color='yellow',
                                       label_font=('Helvetica',18),
                                       label_anchor='w', # n, ne, e, se, s, sw, w, nw, center
                                       border_width=3,
                                       border_color='red',
                                       fg_color='green',
                                       scrollbar_fg_color='brown',
                                       scrollbar_button_color='pink',
                                       scrollbar_button_hover_color='black',
                                       corner_radius=20,)
scf.pack(pady=40)

for x in range(20):
    customtkinter.CTkButton(scf, text='Button').pack(pady=10)






root.mainloop()