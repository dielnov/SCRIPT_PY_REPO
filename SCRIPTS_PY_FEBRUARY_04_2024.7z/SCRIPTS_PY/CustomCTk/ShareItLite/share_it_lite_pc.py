import os, subprocess
os.chdir(os.path.dirname(__file__))

# C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe

#subprocess.run("explorer C:\\Users\\0000 USB VAULT", shell=True, check=True, cwd="C:\\Users\\0000 USB VAULT", capture_output=True)

subprocess.run("C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe 'http://192.168.49.1:2999/pc'", shell=True, check=True, capture_output=True)
