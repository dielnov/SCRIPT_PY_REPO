import os, subprocess, customtkinter
from tkinter import *

os.chdir(os.path.dirname(__file__))

def share_it():
    subprocess.run("explorer http://192.168.49.1:2999/pc", shell=True, check=True, capture_output=True)

def share_it_lite():
    subprocess.run("explorer http://192.168.43.1:2999/pc", shell=True, check=True, capture_output=True)

def share_it_karo():
    subprocess.run("explorer http://192.168.49.1:2999/pc", shell=True, check=True, capture_output=True)

customtkinter.set_appearance_mode('dark')
customtkinter.set_default_color_theme('dark-blue')

root = customtkinter.CTk()

root.title('ShareIT (includes ShareIt Lite & Karo) by AestheticDevs')
#root.iconbitmap('images/eagle.ico')
root.geometry('480x320')

frame = customtkinter.CTkFrame(root)
frame.pack(pady=(40,10))


btnShareIt = customtkinter.CTkButton(frame, width=300, text='ShareIt', command=share_it)
btnShareIt.pack(pady=(40,20))

btnShareItLite = customtkinter.CTkButton(frame, width=300, text='ShareIt Lite', command=share_it_lite)
btnShareItLite.pack(pady=20)

btnShareItKaro = customtkinter.CTkButton(frame, width=300, text='ShareIt Karo', command=share_it_karo)
btnShareItKaro.pack(pady=20)



root.mainloop()
# Written For Fun By Dielnov Muchati(https://github.com/dielnov)
#iCode4Fun