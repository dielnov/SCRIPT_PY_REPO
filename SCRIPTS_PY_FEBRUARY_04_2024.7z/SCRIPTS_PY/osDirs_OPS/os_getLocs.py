# Get certain Path Locations using the OS.Path Module
import os

# Get the Current Working Directory
cwd = os.getcwd()
print(cwd)
# Get The Directory Of This Python File
file_dir = os.path.dirname(__file__)

# Change Current Working Directory TO This File's Directory
os.chdir(file_dir)

def get_file_dir():
    return os.path.dirname(__file__)