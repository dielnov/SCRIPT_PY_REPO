# This script is being developed with focus on WindowsOS for now....
# @dielnov #iCode4Fun
import os

# Get the path for this script file's directory
this_file_path = os.path.dirname(__file__)

# Change Current Working Directory to This File's Directory
os.chdir(this_file_path)

# Get A Tuple Pair (Drive Letter, SomePath)
items = os.path.splitdrive(this_file_path)

drive_letter = items[0]


locations_list = items[1].split('\\')

# windows_user_dirname can (in most cases but not all) be used as the windows_user_account_name
cmnt = 'windows_user_dirname can (in most cases but not all) be used as the windows_user_account_name'
windows_user_dirname = locations_list[2]

def user_profile():
    print('*'*64)
    print('')
    print('This File Path : ',this_file_path)
    print('System Drive Letter : ', drive_letter)
    print('Windows User Directory Name : ', windows_user_dirname)
    print('\n', cmnt)
    print('*'*32)



