import getpass, hashlib

a = getpass.getpass()