import os
import shutil

cwd = os.getcwd()
# Chaqnge cwd to PG18SN Folder First
for f in os.listdir():
    fn, fx = os.path.splitext(f)
    if fx == ".mp4":
        print(f)
        os.rename("." + fn)
    
