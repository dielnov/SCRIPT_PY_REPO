import customtkinter as ctk

def add_todo():
    todo = entry.get()
    label = ctk.CTkLabel(scf, text=todo)
    label.pack()
    entry.delete(0, ctk.END)

root = ctk.CTk()
root.geometry("720x480")
root.title("TO DO LIST")

lb = ctk.CTkLabel(root, text="TO DO LIST", font=ctk.CTkFont(size=30,weight="bold"))
lb.pack(padx=20, pady=(40,10))

scf = ctk.CTkScrollableFrame(root, width=500, height=320)
scf.pack()

entry = ctk.CTkEntry(scf, placeholder_text="ADD TO LIST")
entry.pack(fill="x")

btn = ctk.CTkButton(root, text="ADD TO LIST", width=500, command=add_todo)
btn.pack(pady=20)

root.mainloop()
