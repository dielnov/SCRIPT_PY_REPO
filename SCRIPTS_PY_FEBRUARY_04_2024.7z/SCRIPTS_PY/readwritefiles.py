import os

def write_to_file(write_data,file_name,file_dir_path,file_extension):
    os.chdir(file_dir_path)
    fn_fx = file_name + file_extension
    file_to_write = os.path.join(file_dir_path,fn_fx)
    f = open(file_to_write, "w")
    f.write(write_data)
    f.close()

def create_file(file_name,file_dir_path,file_extension):
    write_to_file(write_data="",file_name=file_name,file_dir_path=file_dir_path,file_extension=file_extension)

def update_file(update_data,file_to_update):
    f = open(file_to_update, "a")
    f.write(update_data)
    f.close()

def read_file(file_to_read):
    f = open(file_to_read, "r")
    read_file_data = f.read()
    return read_file_data

def update_file_top(update_data,file_to_update):
    file_data_old = read_file(file_to_read=file_to_update)
    file_dir_path, fn_fx = os.path.split(file_to_update)
    file_name, file_extension = os.path.splitext(fn_fx)
    write_to_file(write_data=update_data,file_name=file_name,file_dir_path=file_dir_path,file_extension=file_extension)
    update_file(file_data_old,file_to_update)

def clear_file(file_to_clear):
    f = open(file_to_clear,"w")
    f.write("")
    f.close()
