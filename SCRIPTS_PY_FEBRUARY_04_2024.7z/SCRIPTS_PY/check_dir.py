import os

cwd = os.getcwd()
print(cwd)

if os.path.isdir(os.path.join(cwd, "test_dir")):
    print("Folder Exists!!!")
else:
    print("Creating Folder test_dir")
    os.mkdir(os.path.join(cwd, "test_dir"))
