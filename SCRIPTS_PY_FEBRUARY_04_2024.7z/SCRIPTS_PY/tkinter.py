import tkinter as tk

window = tk.Tk()

greeting = tk.Label(text="Hello")
greeting.pack()
window.mainloop()
