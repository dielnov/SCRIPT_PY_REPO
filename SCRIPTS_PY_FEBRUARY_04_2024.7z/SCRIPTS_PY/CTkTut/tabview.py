from tkinter import *
import customtkinter
import os

os.chdir(os.path.dirname(__file__))

customtkinter.set_appearance_mode('dark')
customtkinter.set_default_color_theme('dark-blue')

root = customtkinter.CTk()

root.title('CustomTkinter Practical - TabView')
#root.iconbitmap('images/bomb.ico')
root.geometry('720x480')

tabview = customtkinter.CTkTabview(root)
tabview.pack(padx=20, pady=20)

tab1 = tabview.add('ONE')
tab2 = tabview.add('TWO')
tabview.set('TWO')

btn = customtkinter.CTkButton(tab1, text='button 1')
btn.pack(padx=20, pady=20)

btn2 = customtkinter.CTkButton(tab2, text='button 2')
btn2.pack(padx=20, pady=20)



root.mainloop()