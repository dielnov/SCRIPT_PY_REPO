from tkinter import *
import customtkinter
import os

os.chdir(os.path.dirname(__file__))

customtkinter.set_appearance_mode('dark')
customtkinter.set_default_color_theme('dark-blue')

root = customtkinter.CTk()

root.title('CustomTkinter Practical - ProgressBar')
#root.iconbitmap('images/bomb.ico')
root.geometry('720x480')

state = 1

def prog_move():
    vc = progressbar.get()
    nvc = vc + 0.1
    progressbar.set(nvc)

def prog_step():
    progressbar.step()

def start_stop():
    global state
    if state == 1:
        progressbar.stop()
        state = 0
    if state == 0:
        progressbar.start()
        state = 1


progressbar = customtkinter.CTkProgressBar(root, progress_color='green', mode='indeterminate',determinate_speed=0.1, indeterminate_speed=0.1, orientation='horizontal')
progressbar.pack()

btn = customtkinter.CTkButton(root, text='move', command=prog_move)
btn.pack()

btn2 = customtkinter.CTkButton(root, text='step', command=prog_step)
btn2.pack(pady=10)

btn3 = customtkinter.CTkButton(root, text='start/stop', command=start_stop)
btn3.pack(pady=10)

progressbar.start()



root.mainloop()