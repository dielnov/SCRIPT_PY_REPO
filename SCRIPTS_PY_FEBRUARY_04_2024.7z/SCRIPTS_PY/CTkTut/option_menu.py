import customtkinter as ctk

root = ctk.CTk()
opt_menu = ctk.CTkOptionMenu(root, values=['D','E','F','G','H']).pack()
root.mainloop()