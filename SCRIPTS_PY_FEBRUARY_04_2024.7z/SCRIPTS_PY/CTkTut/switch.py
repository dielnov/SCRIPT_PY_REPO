from tkinter import *
import customtkinter
import os

os.chdir(os.path.dirname(__file__))

root = customtkinter.CTk()

root.title('CustomTkinter Practical - Switch')
#root.iconbitmap('images/bomb.ico')
root.geometry('720x480')

def switch_event():
    print("Switch Toggled, Current Value: ", switch_var.get())
    customtkinter.set_appearance_mode(switch_var.get())



switch_var = customtkinter.StringVar(value='dark')
customtkinter.set_appearance_mode(switch_var.get())
customtkinter.set_default_color_theme('dark-blue')
switch = customtkinter.CTkSwitch(root, text='SWITCH', command=switch_event, variable=switch_var, onvalue='light', offvalue='dark')
switch.pack()

root.mainloop() 