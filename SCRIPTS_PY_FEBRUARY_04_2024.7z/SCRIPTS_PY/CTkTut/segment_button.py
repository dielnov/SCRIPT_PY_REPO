from tkinter import *
import customtkinter
import os

os.chdir(os.path.dirname(__file__))

customtkinter.set_appearance_mode('dark')
customtkinter.set_default_color_theme('dark-blue')

root = customtkinter.CTk()

root.title('CustomTkinter Practical - SegmentedButton') 
#root.iconbitmap('images/bomb.ico')
root.geometry('720x480')

def segment_button_callback(value):
    print('Segment Button Clicked: ', value)


segment_button = customtkinter.CTkSegmentedButton(root, values=['option1','option2','option3','option4'], command=segment_button_callback)
segment_button.set('option2')
segment_button.pack()

root.mainloop()