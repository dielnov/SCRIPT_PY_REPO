import customtkinter as ctk
import os

os.chdir(os.path.dirname(__file__))

def button_callback():
    print('Button Pressed')

root = ctk.CTk()
root.title('CTk Grid System')
root.geometry('400x150')
root.grid_columnconfigure(0, weight=1)

btn = ctk.CTkButton(root, text='BUTTON', command=button_callback)
btn.grid(row=0, column=0, padx=20, pady=20)
root.mainloop()