import time
from datetime import date

if date(2024,1,11) < date(2024,1,12):
    print('true')

if date.today() == date(2024,1,11):
    print('gool')


