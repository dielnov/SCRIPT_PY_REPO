import os
os.chdir(os.path.dirname(__file__))

import osGetUserProfile as usr

print(usr.windows_user_dirname)
usr.user_profile()