import subprocess

subprocess.run("explorer C:\\Users\\0000 USB VAULT", shell=True, check=True, cwd="C:\\Users\\0000 USB VAULT", capture_output=True)
