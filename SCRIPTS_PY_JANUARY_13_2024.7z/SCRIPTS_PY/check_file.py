import os

cwd = os.getcwd()
print(cwd)

if os.path.isfile(os.path.join(cwd, "logs.txt")):
    print("File Exists!!!")
else:
    print("Creating File logs.txt")
    f = open("C:\\Users\\ShamvaPC8\\Desktop\\RockZW\\SCRIPTS_PY\\logs.txt", "w")
    f.write("Test File")
    f.close()
