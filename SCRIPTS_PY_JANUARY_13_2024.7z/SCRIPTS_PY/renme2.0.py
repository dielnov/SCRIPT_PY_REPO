import os
import shutil

cwd = os.getcwd()

for f in os.listdir():
	fn, fx = os.path.splitext(f)
	print(fn, fx)
	print('#'*64)
	rd, rp = os.path.splitdrive(os.getcwd())
	print(rd, rp)
	print('#'*64)
