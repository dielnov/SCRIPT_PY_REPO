from tkinter import *
import customtkinter
import os

os.chdir(os.path.dirname(__file__))

customtkinter.set_appearance_mode(' dark')
customtkinter.set_default_color_theme('dark-blue')

root = customtkinter.CTk()

root.title('CustomTkinter Practical - Scrollable Frames')
root.iconbitmap('images/bomb.ico')
root.geometry('700x300')






root.mainloop()