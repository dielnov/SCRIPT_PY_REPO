import os

exe_list = []
root_dir = os.getcwd()

print('Root Is : {}'.format(root_dir))
for root, dirs, files in os.walk(os.getcwd()):
    for f in files:
        fn, fx = os.path.splitext(f)
        print(root)
        if fx == '.exe' or fx == '.js' or fx == '.inf' or fx == '.bat' or fx == '.cmd' or fx == '.lnk':
            print(f)
            i = input('Y to Delete or N to Skip & Continue... :\n')
            if i == 'Y' or i == 'y':
                os.remove(os.path.join(root,f))
            else:
                if i == 'N' or i == 'n':
                    print('Canceling...')
                    pass