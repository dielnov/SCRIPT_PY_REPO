import tkinter

root = tkinter.Tk()

bt = tkinter.Button(text="Click Me")
bt.pack()

bt2 = tkinter.Button(text="Click Me Too!")
bt2.pack()

lb = tkinter.Label(text="Masasi EpaLabel")
lb.pack()
root.mainloop()
