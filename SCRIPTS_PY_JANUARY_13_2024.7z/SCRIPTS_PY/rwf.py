import os
from readwritefiles import *

create_file("test_file",os.getcwd(),".tstf")
write_to_file("dielnov","test_file",os.getcwd(),".tstf")
update_file_top("muchati",os.path.join(os.getcwd(),"test_file.tstf"))
print(read_file(os.path.join(os.getcwd(),"test_file.tstf")))