import os

exe_list = []
root_dir = os.getcwd()

print('Root Is : {}'.format(root_dir))
for root, dirs, files in os.walk(os.getcwd()):
    for f in files:
        fn, fx = os.path.splitext(f)
        if fx == '.exe' || fx == '.js' || fx == '.inf' || fx == '.bat' || fx == '.cmd':
            print(f)
            print(root)
            os.remove(os.path.join(root,f))
            print('#'*32)
            
