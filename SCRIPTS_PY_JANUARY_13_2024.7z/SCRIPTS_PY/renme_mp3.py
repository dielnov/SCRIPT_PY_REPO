import os
import shutil

cwd = os.getcwd()
album = input("Enter Album Title: ")
for f in os.listdir():
    fn, fx = os.path.splitext(f)
    if fx == ".mp3":
        print(f)
        os.rename("." + fn)
    
